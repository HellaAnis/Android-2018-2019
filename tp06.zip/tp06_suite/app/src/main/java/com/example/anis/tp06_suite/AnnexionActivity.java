package com.example.anis.tp06_suite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AnnexionActivity extends AppCompatActivity {

EditText pays1a,pays2a;
TextView reponse_a;
Button btn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_annexion);

pays2a = (EditText)findViewById(R.id.pays2a) ;
        pays1a = (EditText)findViewById(R.id.pays1a) ;
            reponse_a =(TextView) findViewById(R.id.reponse_a);

    }


    public void calcul_a(View view) {

        
    }
}
