package com.example.anis.tp06_suite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText pays_m ;
    TextView surface;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pays_m = (EditText) findViewById(R.id.pays0);
        surface = (TextView) findViewById(R.id.surface);


    }

    public void remplirBase(View view) {
        AccesDonnees remplire = new AccesDonnees(this);
        remplire.init();
        Toast a=Toast.makeText(this,"good",Toast.LENGTH_LONG);
                a.show();


        Log.d("Erreur","erreur dans la fonction init de la class acces donnés");
    }

    public void aire(View view) {
        // la fonction qui utilise la fonction surface

        Log.i("tp6_suit_activity","debut ");

        Toast a=Toast.makeText(this,pays_m.getText().toString(),Toast.LENGTH_LONG);
        a.show();
        //AccesDonnes pour faire l'acces a la class ACCESDONNEES pour utilise la fonction surface
        //On donne comme arg 'this' le context
        AccesDonnees afficher  = new AccesDonnees(this);
        //des logs pour chercher les erreurs
        Log.i("tp6_suit_activity",pays_m.getText().toString());
        Log.i("tp6_suit_activity","");
        //affichage dans le txtview
        int result = afficher.surface(pays_m.getText().toString().trim());
        surface.setText(""+result);
        Log.i("tp6_suit_activity","fin ");




    }

    public void densite(View view) {


        Intent intent = new Intent(this,DensiteActivity.class);
        startActivity(intent);


    }

    public void annexion(View view) {
        Intent intent = new Intent(this,AnnexionActivity.class);
        startActivity(intent);

    }
}
