package com.example.anis.tp06_suite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class DensiteActivity extends AppCompatActivity {

    EditText pays,annee1,annee2;
    TextView v;
  //  Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_densite);

        pays = (EditText) findViewById(R.id.pays);
        annee1 = (EditText) findViewById(R.id.annee1);
        annee2 = (EditText) findViewById(R.id.annee2);
        v= (TextView) findViewById(R.id.reponse);



    }

    public void calcul(View view) {


        Log.i("tp6_suit_activity","debut ");

        Toast a=Toast.makeText(this,pays.getText().toString(),Toast.LENGTH_LONG);
        a.show();

        AccesDonnees afficher  = new AccesDonnees(this);

        int d1 = afficher.densite(pays.getText().toString().trim(),(annee1.getText().toString()));

        int d2 = afficher.densite(pays.getText().toString().trim(),(annee2.getText().toString()));

        int d = afficher.surface(pays.getText().toString().trim());

        int result=(((d2-d1)*100)/d);
        v.setText("Densite = "+""+result+"/-population annee1 :"+d1+"-population annee2 :"+d2+"-suraface :"+d);
        Log.i("tp6_suit_activity","fin ");


    }
}