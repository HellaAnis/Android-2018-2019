package com.example.anis.tp06;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseGeo extends SQLiteOpenHelper {
    
    public final static int VERSION = 9;
    public final static String DB_NAME = "base_geo";
    public final static String TABLE_GEO = "geo";
    public final static String COLONNE_PAYS = "pays";
    public final static String COLONNE_CAPITALE = "capitale";
    public final static String COLONNE_CONTINENT = "continent";
    public final static String COLONNE_SUPERFICIE = "superficie";


    public final static String TABLE_STAT = "stat";
    public final static String COLONNE_ANNEE = "annee";
    public final static String COLONNE_POPULATION = "population";

    public final static String CREATE_GEO = "create table " + TABLE_GEO + "(" +
            COLONNE_PAYS + " string primary key, " +
            COLONNE_CAPITALE + " string, " +
            COLONNE_CONTINENT + " string, " +
            COLONNE_SUPERFICIE + " integer " + ");";


    public final static String CREATE_STAT = "create table " + TABLE_STAT + "(" +
            COLONNE_PAYS + " string references geo, " +
            COLONNE_ANNEE + " integer, " +
            COLONNE_POPULATION + " integer," +
            "primary key(" + COLONNE_PAYS + ", " + COLONNE_ANNEE + "));";

    private static BaseGeo ourInstance;

    public static BaseGeo getInstance(Context context) {
        if (ourInstance == null)
            ourInstance = new BaseGeo(context);
        return ourInstance;
    }

    private BaseGeo(Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_GEO);
        db.execSQL(CREATE_STAT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion > oldVersion) {
            db.execSQL("drop table if exists " + TABLE_GEO);
            db.execSQL("drop table if exists " + TABLE_STAT);
            onCreate(db);
        }
    }
}
